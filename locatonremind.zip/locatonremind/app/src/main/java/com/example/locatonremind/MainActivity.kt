// KODE FINAL - DENGAN TIME PICKER DIALOG KUSTOM YANG TERBUKTI
package com.example.locatonremind

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.locatonremind.ui.theme.LocatonremindTheme
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

// MODEL DATA (Tidak berubah)
data class Reminder(val id: UUID = UUID.randomUUID(), val title: String, val date: String, val time: String)
data class ReminderInput(val title: String = "", val date: String = "Select Date", val time: String = "Select Time")
data class LocationDetails(val city: String, val countryName: String, val countryCode: String, val countryFlag: String)

// BAGIAN UTAMA, NAVIGASI & SPLASH SCREEN (Tidak berubah)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LocatonremindTheme { AppNavigator() } }
    }
}
enum class Screen { SPLASH, REMINDER }
@Composable
fun AppNavigator() {
    var currentScreen by remember { mutableStateOf(Screen.SPLASH) }
    when (currentScreen) {
        Screen.SPLASH -> SplashScreen(onTimeout = { currentScreen = Screen.REMINDER })
        Screen.REMINDER -> ReminderScreen()
    }
}
@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    val context = LocalContext.current
    var locationDetails by remember { mutableStateOf<LocationDetails?>(null) }
    var statusText by remember { mutableStateOf("Detecting Location...") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) { getLocation(context) { details -> locationDetails = details }
        } else {
            statusText = "Permission Denied"
            locationDetails = LocationDetails("World", "Unknown", "", "🌏")
        }
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            getLocation(context) { details -> locationDetails = details }
        } else { permissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION) }
        delay(3000)
        onTimeout()
    }
    Box(Modifier.fillMaxSize().background(Color(0xFFB3E5FC)), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            if (locationDetails == null) {
                CircularProgressIndicator(color = Color.White); Spacer(Modifier.height(16.dp)); Text(text = statusText, color = Color.Black)
            } else {
                Text(text = "Hello, ${locationDetails!!.city}", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.Black, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp))
                Spacer(Modifier.height(16.dp))
                if (locationDetails!!.countryCode == "ID") {
                    val logoResId = getLogoResourceId(context, locationDetails!!.city)
                    Image(painterResource(id = logoResId), "Logo Pemda", modifier = Modifier.size(100.dp))
                } else { Text(text = locationDetails!!.countryFlag, fontSize = 100.sp) }
            }
        }
    }
}

// LAYAR REMINDER UTAMA (Tidak berubah)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReminderScreen() {
    val reminders = remember { mutableStateListOf<Reminder>() }
    var showDialog by remember { mutableStateOf(false) }
    var reminderInput by remember { mutableStateOf(ReminderInput()) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("My Reminders") }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary, titleContentColor = MaterialTheme.colorScheme.onPrimary)) },
        floatingActionButton = { FloatingActionButton(onClick = { showDialog = true }) { Icon(Icons.Filled.Add, "Add Reminder") } }
    ) { paddingValues ->
        if (reminders.isEmpty()) { Box(Modifier.fillMaxSize().padding(paddingValues), Alignment.Center) { Text("No reminders yet. Tap '+' to add one.", textAlign = TextAlign.Center) }
        } else {
            LazyColumn(Modifier.padding(paddingValues), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(reminders) { reminder -> ReminderCard(reminder) }
            }
        }
        if (showDialog) {
            AddReminderDialog(
                input = reminderInput,
                onInputChange = { newInput -> reminderInput = newInput },
                onDismiss = { showDialog = false; reminderInput = ReminderInput() },
                onAddReminder = {
                    if (reminderInput.title.isNotBlank() && reminderInput.date != "Select Date" && reminderInput.time != "Select Time") {
                        reminders.add(Reminder(title = reminderInput.title, date = reminderInput.date, time = reminderInput.time))
                        showDialog = false
                        reminderInput = ReminderInput()
                    }
                }
            )
        }
    }
}

// --- INI KOMPONEN BARU YANG TERBUKTI BERHASIL ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    dismissButton: @Composable () -> Unit,
    content: @Composable () -> Unit,
) {
    Dialog(onDismissRequest = onDismissRequest) {
        Surface(
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = 6.dp,
            modifier = Modifier
                .wrapContentWidth()
                .wrapContentHeight()
        ) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                content()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    dismissButton()
                    Spacer(modifier = Modifier.width(8.dp))
                    confirmButton()
                }
            }
        }
    }
}


// DIALOG UNTUK MENAMBAH REMINDER (Dengan pemanggilan TimePickerDialog yang benar)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddReminderDialog(input: ReminderInput, onInputChange: (ReminderInput) -> Unit, onDismiss: () -> Unit, onAddReminder: () -> Unit) {
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss) {
        Card(Modifier.clip(RoundedCornerShape(16.dp))) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("New Reminder", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = input.title, onValueChange = { onInputChange(input.copy(title = it)) }, label = { Text("Reminder Title") }, leadingIcon = { Icon(Icons.Default.Notifications, null) })
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = input.date, onValueChange = {}, readOnly = true, label = { Text("Date") }, leadingIcon = { Icon(Icons.Default.DateRange, null) }, modifier = Modifier.clickable { showDatePicker = true })
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = input.time, onValueChange = {}, readOnly = true, label = { Text("Time") }, leadingIcon = { Icon(Icons.Default.Schedule, null) }, modifier = Modifier.clickable { showTimePicker = true })
                Spacer(Modifier.height(24.dp))
                Row {
                    Button(onClick = onAddReminder) { Text("Add") }
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                }
            }
        }
    }

    if (showDatePicker) {
        val calendar = Calendar.getInstance()
        val initialDateMillis = if (input.date != "Select Date") {
            try { SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).parse(input.date)?.time ?: calendar.timeInMillis } catch (e: Exception) { calendar.timeInMillis }
        } else { calendar.timeInMillis }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialDateMillis, initialDisplayedMonthMillis = initialDateMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = millis }
                            onInputChange(input.copy(date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(cal.time)))
                        }
                        showDatePicker = false
                    }
                ) { Text("OK") }
            },
            dismissButton = { TextButton({ showDatePicker = false }) { Text("Cancel") } }
        ) { DatePicker(state = datePickerState) }
    }

    if (showTimePicker) {
        val timePickerState = remember(input.time) {
            val calendar = Calendar.getInstance()
            var initialHour = calendar.get(Calendar.HOUR_OF_DAY)
            var initialMinute = calendar.get(Calendar.MINUTE)
            if (input.time != "Select Time") {
                try {
                    val timeParts = input.time.split(":").map { it.toInt() }
                    if (timeParts.size == 2) { initialHour = timeParts[0]; initialMinute = timeParts[1] }
                } catch (e: Exception) { /* Biarkan */ }
            }
            TimePickerState(initialHour, initialMinute, true)
        }

        // --- INI PEMANGGILAN YANG SEKARANG BENAR ---
        TimePickerDialog(
            onDismissRequest = { showTimePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val cal = Calendar.getInstance().apply {
                            set(Calendar.HOUR_OF_DAY, timePickerState.hour)
                            set(Calendar.MINUTE, timePickerState.minute)
                        }
                        onInputChange(input.copy(time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(cal.time)))
                        showTimePicker = false
                    }
                ) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) { Text("Cancel") }
            }
        ) {
            TimePicker(state = timePickerState)
        }
    }
}

// KOMPONEN DAN FUNGSI BANTU LAINNYA (Tidak berubah)
@Composable
fun ReminderCard(reminder: Reminder) {
    Card(Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(4.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp)) {
            Text(reminder.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.DateRange, "Date", Modifier.size(16.dp)); Spacer(Modifier.width(8.dp)); Text(reminder.date, style = MaterialTheme.typography.bodyMedium) }
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Schedule, "Time", Modifier.size(16.dp)); Spacer(Modifier.width(8.dp)); Text(reminder.time, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}
@SuppressLint("MissingPermission")
private fun getLocation(context: Context, onResult: (LocationDetails) -> Unit) {
    try {
        LocationServices.getFusedLocationProviderClient(context).lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                try {
                    val geocoder = Geocoder(context, Locale.getDefault())
                    @Suppress("DEPRECATION") val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    if (addresses?.isNotEmpty() == true) {
                        val ad = addresses[0]; val city = ad.locality ?: ad.subAdminArea ?: "Unknown City"
                        onResult(LocationDetails(city, ad.countryName ?: "Unknown", ad.countryCode ?: "", countryCodeToEmoji(ad.countryCode ?: "")))
                    } else { onResult(LocationDetails("Unknown", "Unknown", "", "❓")) }
                } catch (e: Exception) { onResult(LocationDetails("Service Not Available", "", "", "⚙️")) }
            } else { onResult(LocationDetails("Can't find location", "", "", "🛰️")) }
        }.addOnFailureListener { onResult(LocationDetails("Failed to get location", "", "", "🔌")) }
    } catch (e: Exception) { onResult(LocationDetails("Location Services Error", "", "", "⛔")) }
}
private fun getLogoResourceId(context: Context, city: String): Int {
    val normalizedCity = city.lowercase(Locale.getDefault())
    val logoMap = mapOf("jakarta" to "pemda_jakarta", "bandung" to "pemda_bandung", "surabaya" to "pemda_surabaya", "cikarang" to "pemda_bekasi", "mustika jaya" to "pemda_bekasi", "bekasi" to "pemda_bekasi")
    val fileName = logoMap.entries.find { normalizedCity.contains(it.key) }?.value
    return if (fileName != null) context.resources.getIdentifier(fileName, "drawable", context.packageName).takeIf { it != 0 } ?: R.drawable.logo_garuda else R.drawable.logo_garuda
}
private fun countryCodeToEmoji(countryCode: String): String {
    if (countryCode.length != 2) return "❓"; return countryCode.uppercase(Locale.US).map { char -> Character.toChars(char.code + 0x1F1A5) }.joinToString("")
}
@OptIn(ExperimentalMaterial3Api::class)
@Preview(showBackground = true, name = "Reminder Screen Makeover")
@Composable
fun ReminderScreenPreview() { LocatonremindTheme { ReminderScreen() } }
